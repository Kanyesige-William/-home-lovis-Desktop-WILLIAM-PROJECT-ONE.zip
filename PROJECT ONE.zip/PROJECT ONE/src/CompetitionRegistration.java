import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;
public class CompetitionRegistration{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the required information below to register!");
        System.out.println("Enter your First Name: ");
        String firstName = scanner.nextLine();
        System.out.println("Enter your Last Name: ");
        String lastName = scanner.nextLine();
        System.out.println("Enter your Email Address: ");
        String email = scanner.nextLine();
        System.out.println("Enter your Date Of Birth: ");
        String dateOfBirth = scanner.nextLine();
        System.out.println("Enter your School Registration Number: ");
        String schoolRegistrationNumber = scanner.nextLine();
        System.out.print("Enter the path to your image: ");
        String imagePath = scanner.nextLine();
        File imageFile = new File(imagePath);
        if (!imageFile.exists() || !imageFile.isFile()) {
            System.out.println("File does not exist. Please try again with the right Image Allocation.");
            return;
        }
        try{
            File uploadDir = new File("Uploads");
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            File uploadedImage = new File(uploadDir, imageFile.getName());
            Files.copy(imageFile.toPath(), uploadedImage.toPath());
            System.out.println("Registration complete! Here are your details:");
            System.out.println("Name: " + firstName + " " + lastName);
            System.out.println("Email: " + email);
            System.out.println("Date of Birth: " + dateOfBirth);
            System.out.println("School Registration Number: " + schoolRegistrationNumber);
            System.out.println("Image uploaded to: " + uploadedImage.getAbsolutePath());

        } catch (IOException e) {
            System.out.println("An error occurred while uploading the image.");
            e.printStackTrace();
        }
        scanner.close();
    }
}